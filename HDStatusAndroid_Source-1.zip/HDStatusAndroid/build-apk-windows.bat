@echo off
echo Building HD Status debug APK...
gradle assembleDebug
if errorlevel 1 (
  echo Build failed. Open the project in Android Studio and check Gradle sync errors.
  pause
  exit /b 1
)
echo APK path: app\build\outputs\apk\debug\app-debug.apk
pause
